<?php
/*
    Plugin Name: WebRotate 360 Product Viewer for WordPress
    Plugin URI: http://www.webrotate360.com/360-product-viewer.html
    Description: WebRotate 360 Product Viewer WordPress Integration
    Version: 3.1.2
    Author: WebRotate 360 LLC
    Author URI: http://www.webrotate360.com
    License: GPLv2
*/

if (!defined("ABSPATH"))
    exit;

class WR360WooCommerce
{
    private $wooVersion;

    public function __construct()
    {
        $this->wooVersion = $this->get_woocommerce_version();

        if (is_admin())
        {
            add_action("woocommerce_product_write_panel_tabs", array($this, "webrotate360_tab_options_tab"));
            add_action("woocommerce_product_write_panels", array($this, "webrotate360_tab_options"));
            add_action("woocommerce_process_product_meta", array($this, "webrotate360_save_product"));
        }
        else
        {
            $templateName = version_compare($this->wooVersion, "3.0", ">=" )
                ? "woocommerce_single_product_image_thumbnail_html" : "woocommerce_single_product_image_html";

            add_filter($templateName, array($this, "webrotate360_replace_product_image"), 100, 2);
        }
    }

    public function webrotate360_replace_product_image($content, $thumbId)
    {
        global $post;
        global $product;

        if (empty($post->ID))
            return ($content);

        if (version_compare($this->wooVersion, "3.0", ">=" )) {
            if ($thumbId !== get_post_thumbnail_id($post->ID))
                return ("");
        }

        $wr360config = esc_url(get_post_meta($post->ID, "_wr360config", true));
        $wr360root = esc_url(get_post_meta($post->ID, "_wr360root", true));

        if (empty($wr360config) && empty($wr360root))
            return ($content);

        $viewAlias = preg_replace('/\s+/', '', $product->get_sku());
        if (empty($viewAlias))
            $viewAlias = $post->ID;

        $defConfig = new WR360DefaultsConfig();
        $defConfig->init_shortcode(array("name" => $post->ID, "config" => $wr360config, "rootpath" => $wr360root));

        $replace = "";
        $replace .= "<div class='wr360woowrap'>";
        $replace .= "<div id='%s' class='webrotate360 wr360embed' style='width:%s; height:%s;' data-imagerotator='{";
        $replace .= '"onready":"%s", "graphics":"%s", "licfile":"%s", "rootpath":"%s", "xmlfile":"%s", "basewidth":%s, "events":%s, "name":"%s", "minheight":%s, "background":"%s"';
        $replace .= "}'></div></div>";

        return (sprintf(
            $replace,
            'wr360woo_' . $defConfig->name,
            (strpos($defConfig->viewerWidth, '%') === FALSE) ? $defConfig->viewerWidth . 'px' : $defConfig->viewerWidth,
            $defConfig->viewerHeight . "px",
            $defConfig->callback,
            $defConfig->graphicsPath,
            $defConfig->licensePath,
            $defConfig->rootPath,
            $defConfig->config,
            $defConfig->baseWidth,
            $defConfig->useGoogleEvents ? "true" : "false",
            $viewAlias,
            $defConfig->minHeight,
            $defConfig->background));
    }

    public function webrotate360_save_product($post_id)
    {
        if (isset($_POST["_wr360config"]))
        {
            update_post_meta($post_id, "_wr360config", esc_url($_POST["_wr360config"]));
        }

        if (isset($_POST["_wr360root"]))
        {
            update_post_meta($post_id, "_wr360root", esc_url($_POST["_wr360root"]));
        }
    }

    public function webrotate360_tab_options_tab()
    {
        echo '<li class="custom_tab"><a href="#webrotate360woo_tab_data" id="webrotate360woo_tab"><span>WebRotate 360</span></a></li>';
    }

    public function webrotate360_tab_options()
    {
        echo '<style type="text/css">a#webrotate360woo_tab:before{content: "\f463" !important;}</style>
            <div id="webrotate360woo_tab_data" class="panel woocommerce_options_panel"><div class="options_group">';

        woocommerce_wp_text_input(array(
            "id" => "_wr360config",
            "label" => "Config File URL",
            "placeholder" => "",
            "desc_tip" => true,
            "description" => sprintf("Config File URL")
        ));

        woocommerce_wp_text_input(array(
            "id" => "_wr360root",
            "label" => "Root Path",
            "placeholder" => "",
            "desc_tip" => true,
            "description" => sprintf("Root Path")
        ));

        echo "</div></div>";
    }

    private function get_woocommerce_version()
    {
        if (!function_exists('get_plugins'))
            require_once(ABSPATH . 'wp-admin/includes/plugin.php');

        $plugin_folder = get_plugins('/' . 'woocommerce');
        $plugin_file = 'woocommerce.php';

        $version = $plugin_folder[$plugin_file]['Version'];
        if (isset($version))
            return ($version);

        return null;
    }
}